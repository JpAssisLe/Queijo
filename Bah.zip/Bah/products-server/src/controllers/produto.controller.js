const Produto = require('../models/Produto');

exports.criarProduto = async (req, res) => {
    try {
        const { nome, preco, categoria } = req.body;
        const novoProduto = new Produto({
            nome,
            preco,
            categoria
        });
        
        if(req.file) {
            novoProduto.imagem.dados = req.file.buffer;
            novoProduto.imagem.contentType = req.file.mimetype;
        }

        await novoProduto.save();
        res.status(201).json(novoProduto);
    }
    catch(err) {
        res.status(400).json({erro: err.mesage});
    }
}

exports.listarProdutos = async (req, res) => {
    try {
        const produtos = await Produto.find();
        res.json(produtos);
    }
    catch(err) {
        res.status(500).json({ erro : err.mesage});
    }
}

exports.buscarPorId = async (req, res) => {
    try {
        const produto = await Produto.findById(req.params.id);
        if (!produto) return res.status(404).json({ erro: 'Produto não encontrado' });
        res.json(produto);
    } catch (err) {
        res.status(500).json({ erro: err.message });
    }
};

exports.atualizarProduto = async (req, res) => {
    try {
        const { nome, preco, categoria } = req.body;

        const dadosAtualizados = {
            nome,
            preco,
            categoria
        };

        if (req.file) {
            dadosAtualizados.imagem = {
                dados: req.file.buffer,
                contentType: req.file.mimetype
            };
        }

        const produtoAtualizado = await Produto.findByIdAndUpdate(
            req.params.id,
            dadosAtualizados,
            { new: true } // retorna o novo documento
        );

        if (!produtoAtualizado) {
            return res.status(404).json({ erro: 'Produto não encontrado' });
        }

        res.json(produtoAtualizado);
    } catch (err) {
        res.status(400).json({ erro: err.message });
    }
};


exports.removerPorId = async (req, res) => {
    try {
        const produto = await Produto.findByIdAndDelete(req.params.id);
        if (!produto) return res.status(404).json({ erro: 'Produto não encontrado' });
        res.json({ mensagem: 'Produto removido com sucesso' });
    } catch (err) {
        res.status(500).json({ erro: err.message });
    }
};