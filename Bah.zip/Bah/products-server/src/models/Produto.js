const mongoose = require('mongoose');

const ProdutoSchema = new mongoose.Schema({
    nome: {type: String, requered: true},
    preco: {type: Number, required: true},
    categoria: {type: String },
    imagem: {
        dados: Buffer,
        contentType: String
    }
});

module.exports = mongoose.model('Produto', ProdutoSchema);