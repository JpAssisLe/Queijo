const express = require('express');
const router = express.Router();
const produtoController = require('../controllers/produto.controller');
const multer = require('multer');
const upload = multer(); // armazenamento em memória

router.post('/produtos', upload.single('imagem'), produtoController.criarProduto);
router.get('/produtos', produtoController.listarProdutos);
router.get('/produtos/:id', produtoController.buscarPorId);
router.delete('/produtos/:id', produtoController.removerPorId);
router.put('/produtos/:id', upload.single('imagem'), produtoController.atualizarProduto);

module.exports = router;