
import React from 'react';
import styles from './ProductCard.module.css';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const ProductCard = ({ produto, onDelete, modo }) => {
    const navigate = useNavigate();

    const handleDelete = async () => {
        try {
            await axios.delete(`${process.env.REACT_APP_SERVER_API_URL}/produtos/${produto._id}`);
            onDelete(produto._id);
        } catch (error) {
            console.error('Erro ao deletar seu queijo:', error);
        }
    };

    const imagemBase64 = produto.imagem?.dados
        ? `data:${produto.imagem.contentType};base64,${btoa(
            String.fromCharCode(...new Uint8Array(produto.imagem.dados.data))
        )}`
        : '';

    return (
        <div className={styles.card}>
            {imagemBase64 && <img src={imagemBase64} alt={produto.nome} className={styles.image} />}
            <h3 onClick={() => navigate(`/produto/${produto._id}`)} className={styles.link}>
                {produto.nome}
            </h3>
            <p>Preço: R$ {produto.preco.toFixed(2)}</p>
            <p>Categoria: {produto.categoria}</p>

            {modo === 'atualizar' && (
                <>
                    <button onClick={() => navigate(`/cadastro/${produto._id}`)}>Atualizar</button>
                    <button onClick={handleDelete}>Excluir</button>
                </>
            )}
        </div>
    );
};

export default ProductCard;
