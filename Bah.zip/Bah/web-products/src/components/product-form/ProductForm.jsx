// src/components/product-form/ProductForm.jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const ProductForm = () => {
  const { id } = useParams();
  const [nome, setNome] = useState('');
  const [preco, setPreco] = useState('');
  const [categoria, setCategoria] = useState('');
  const [imagem, setImagem] = useState(null);
  const [preview, setPreview] = useState(null);

  useEffect(() => {
    if (id) {
      axios
        .get(`${process.env.REACT_APP_SERVER_API_URL}/produtos/${id}`)
        .then(res => {
          const produto = res.data;
          setNome(produto.nome);
          setPreco(produto.preco);
          setCategoria(produto.categoria);
          if (produto.imagem?.dados) {
            const img = `data:${produto.imagem.contentType};base64,${btoa(
              String.fromCharCode(...new Uint8Array(produto.imagem.dados.data))
            )}`;
            setPreview(img);
          }
        })
        .catch(err => console.error('Erro ao carregar seu Queijo:', err));
    }
  }, [id]);

  const handleImagemChange = e => {
    const file = e.target.files[0];
    setImagem(file);
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setPreview(reader.result);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async e => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('nome', nome);
    formData.append('preco', preco);
    formData.append('categoria', categoria);
    if (imagem) formData.append('imagem', imagem);

    try {
      if (id) {
        await axios.put(
          `${process.env.REACT_APP_SERVER_API_URL}/produtos/${id}`,
          formData
        );
        alert('Queijo atualizado com sucesso!');
      } else {
        await axios.post(
          `${process.env.REACT_APP_SERVER_API_URL}/produtos`,
          formData
        );
        alert('Queijo cadastrado com sucesso!');
      }

      // limpa campos
      setNome('');
      setPreco('');
      setCategoria('');
      setImagem(null);
      setPreview(null);
    } catch (error) {
      console.error('Erro ao salvar seu Queijo:', error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>{id ? 'Atualizar Produto' : 'Cadastrar Produto'}</h2>

      <input
        type="text"
        value={nome}
        onChange={e => setNome(e.target.value)}
        placeholder="Nome"
        required
      />

      <input
        type="number"
        value={preco}
        onChange={e => setPreco(e.target.value)}
        placeholder="Preço"
        required 
        min={0}
      />

      <input
        type="text"
        value={categoria}
        onChange={e => setCategoria(e.target.value)}
        placeholder="Categoria"
      />

      {/* botão customizado para upload de imagem */}
      <label htmlFor="imagem" className="file-upload-label">
        Escolher imagem
      </label>
      <input
        type="file"
        id="imagem"
        onChange={handleImagemChange}
      />

      {/* preview */}
      {preview && (
        <img
          src={preview}
          alt="Preview"
          style={{
            maxWidth: '100%',
            marginTop: '10px',
            borderRadius: '8px'
          }}
        />
      )}

      <button type="submit">{id ? 'Atualizar' : 'Cadastrar'}</button>
    </form>
  );
};

export default ProductForm;
