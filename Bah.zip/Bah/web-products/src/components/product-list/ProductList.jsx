
import { useEffect, useState } from 'react';
import axios from 'axios';
import ProductCard from '../product-card/ProductCard';
import styles from './ProductList.module.css';

const ProductList = () => {
    const [produtos, setProdutos] = useState([]);

    useEffect(() => {
        axios.get(`${process.env.REACT_APP_SERVER_API_URL}/produtos`)
            .then(response => {
                setProdutos(response.data);
            })
            .catch(error => {
                console.error("Erro ao carregar seus Queijos: ", error);
            });
    }, []);

    const handleDelete = (id) => {
        setProdutos(prev => prev.filter(p => p._id !== id));
    };

    return (
        <div className={styles.wrapper}>
            <h2>Lista de Produtos</h2>
            <div className={styles.container}>
                {
                    produtos.map(produto => (
                        <ProductCard key={produto._id} produto={produto} onDelete={handleDelete} />
                    ))
                }
            </div>
        </div>
    );
};

export default ProductList;
