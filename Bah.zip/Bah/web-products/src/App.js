
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home/Home';
import Cadastro from './pages/Cadastro/Cadastro';
import Produto from './pages/Produto/Produto';
import Atualizar from './pages/Atualizar/Atualizar';
import './App.css';

function App() {
  console.log(`SERVER: ${process.env.REACT_APP_SERVER_API_URL}`)
  return (
    <Router>
      <div className="navbar">
        <Link to="/">Queijos</Link>
        <Link to="/cadastro">Cadastrar</Link>
        <Link to="/atualizar">Atualizar</Link>
      </div>
      <div className="conteudo">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/cadastro" element={<Cadastro />} />
          <Route path="/cadastro/:id" element={<Cadastro />} />
          <Route path="/produto/:id" element={<Produto />} />
          <Route path="/atualizar" element={<Atualizar />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
