
import React from 'react';
import ProductForm from '../../components/product-form/ProductForm';
import styles from './Cadastro.module.css';

const Cadastro = () => {
  return (
    <div className={styles.cadastroContainer}>
      <ProductForm />
    </div>
  );
};

export default Cadastro;
