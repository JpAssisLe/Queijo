
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import ProductCard from '../../components/product-card/ProductCard';
import styles from './Produto.module.css';

const Produto = () => {
  const { id } = useParams();
  const [produto, setProduto] = useState(null);

  useEffect(() => {
    axios.get(`${process.env.REACT_APP_SERVER_API_URL}/produtos/${id}`)
      .then(res => setProduto(res.data))
      .catch(err => console.error('Erro ao buscar Queijo:', err));
  }, [id]);

  if (!produto) return <p className={styles.loading}>Carregando...</p>;

  return (
    <div className={styles.produtoContainer}>
      <ProductCard produto={produto} />
    </div>
  );
};

export default Produto;
