
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ProductCard from '../../components/product-card/ProductCard';
import styles from './Atualizar.module.css';

const Atualizar = () => {
  const [produtos, setProdutos] = useState([]);

  useEffect(() => {
    axios.get(`${process.env.REACT_APP_SERVER_API_URL}/produtos`)
      .then(response => {
        setProdutos(response.data);
      })
      .catch(error => {
        console.error("Erro ao carregar seu queijo: ", error);
      });
  }, []);

  const handleDelete = (id) => {
    setProdutos(prev => prev.filter(p => p._id !== id));
  };

  return (
    <div className={styles.atualizarContainer}>
      <h2>Atualizar Produtos</h2>
      <div className={styles.atualizarGrid}>
        {produtos.map(produto => (
          <ProductCard key={produto._id} produto={produto} onDelete={handleDelete} modo="atualizar" />
        ))}
      </div>
    </div>
  );
};

export default Atualizar;
