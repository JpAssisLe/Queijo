
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import ProductCard from '../../components/product-card/ProductCard';
import styles from './Home.module.css';

const Home = () => {
  const [produtos, setProdutos] = useState([]);
  const [idBusca, setIdBusca] = useState('');

  useEffect(() => {
    axios.get(`${process.env.REACT_APP_SERVER_API_URL}/produtos`)
      .then(response => setProdutos(response.data))
      .catch(error => console.error("Erro ao carregar seus queijos: ", error));
  }, []);

  const buscarPorId = async () => {
    if (!idBusca) return;
    try {
      const response = await axios.get(`${process.env.REACT_APP_SERVER_API_URL}/produtos/${idBusca}`);
      setProdutos([response.data]);
    } catch (error) {
      alert('Queijo não encontrado.');
      console.error('Erro na busca:', error);
    }
  };

  return (
    <div className={styles.homeContainer}>
      <div className={styles.buscaPorId}>
        <input
          type="text"
          placeholder="Buscar por ID"
          value={idBusca}
          onChange={(e) => setIdBusca(e.target.value)}
        />
        <button onClick={buscarPorId}>Buscar</button>
      </div>

      <div className={styles.produtosLista}>
        {produtos.map(produto => (
          <ProductCard key={produto._id} produto={produto} />
        ))}
      </div>
    </div>
  );
};

export default Home;
